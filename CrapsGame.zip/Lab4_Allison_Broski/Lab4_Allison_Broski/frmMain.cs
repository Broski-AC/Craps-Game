﻿/* Lab #4
 * Fall Semester 2017
 * Allison Broski
 * ‘I fully understand the following statement. ‘OU PLAGIARISM POLICY
‘All members of the academic community at Oakland are expected to practice and uphold 
‘standards of academic integrity and honesty. An instructor is expected to inform and instruct 
‘students about the procedures and standards of research and documentation required of students 
‘in fulfilling course work. A student is expected to follow such instructions and be sure the rules 
‘and procedures are understood in order to avoid inadvertent misrepresentation of his work. 
‘Students must assume that individual (unaided) work on exams and lab reports and documentation 
‘of sources is expected unless the instructor specifically says that is not necessary.

‘The following definitions are some examples of academic dishonesty:
 ‘Plagiarizing from work of others. Plagiarism is using someone else's work or ideas without 
‘giving the other person credit; by doing this, a student is, in effect, claiming credit for 
‘someone else's thinking. Whether the student has read or heard the information he/she uses, 
‘the student must document the source of information. When dealing with written sources,
‘a clear distinction would be made between quotations (which reproduce information from 
‘the source word-for-word within quotation marks) and paraphrases (which digest the 
‘source information and produce it in the student's own words). Both direct quotations and 
‘paraphrases must be documented. Just because a student rephrases, condenses or selects 
‘from another person's work, the ideas are still the other person's, and failure to give 
‘credit constitutes misrepresentation of the student's actual work and plagiarism of
‘another's ideas. Naturally, buying a paper and handing it in as one's own work is ‘plagiarism.

 ‘Cheating on lab reports falsifying data or submitting data not based on student's own work.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_Allison_Broski
{
    public partial class frmMain : Form
    {
        //Generating random numbers
        //All of these need to be on class level so that the values obtained within the event are maintained 
        //through each iteration of the event unless noted within the code.
        Random r = new Random();
        int RollOne = 0;
        int RollTwo = 0;
        int State = 1;
        int Score = 0;
        int point;

        public frmMain()
        {
            InitializeComponent();
        }

        private void btnRoll_Click(object sender, EventArgs e)
        {
            //get two random numbers
            RollOne = r.Next(1, 7);
            RollTwo = r.Next(1, 7);
            //Total dice roll
            int RollTotal = 0; 
            RollTotal = RollOne + RollTwo; 
            //Display the two random numbers and total on the screen
            lblScoreDice1.Text = RollOne.ToString();
            lblScoreDice2.Text = RollTwo.ToString();
            lblDiceTotal.Text = RollTotal.ToString();


            //Determining the steps if the status equals 1
            if (State == 1)
            {
                if ((RollTotal == 7) || (RollTotal == 11))
                    {
                    lblResults.Visible = true;
                    lblResults.Text = "You Win! Play Again?";
                    Score += 1;
                    State = 1;
                    lblGamePoint.Text = "";
                    picBlackPuck.Visible = true;
                    picFour.Visible = false;
                    picFive.Visible = false;
                    picSix.Visible = false;
                    picEight.Visible = false;
                    picNine.Visible = false;
                    picTen.Visible = false;
                    lblGameScore.Text = Score.ToString();
                }
                else if ((RollTotal == 2) || (RollTotal == 3) || (RollTotal == 12))
                {
                    lblResults.Visible = true;
                    lblResults.Text = "You Lose! Play Again?";
                    Score -= 1;
                    State = 1;
                    lblGamePoint.Text = "";
                    picBlackPuck.Visible = true;
                    picFour.Visible = false;
                    picFive.Visible = false;
                    picSix.Visible = false;
                    picEight.Visible = false;
                    picNine.Visible = false;
                    picTen.Visible = false;
                    lblGameScore.Text = Score.ToString();
                }
                else
                {
                    lblResults.Visible = true;
                    lblResults.Text = "Roll Again!";
                    Score += 0;
                    State += 1;
                    point = RollTotal;
                    lblGamePoint.Text = RollTotal.ToString();
                    lblGameScore.Text = Score.ToString();

                    //Display the puck value
                    if (point == 4)
                    {
                        picBlackPuck.Visible = false;
                        picFour.Visible = true;
                        picFive.Visible = false;
                        picSix.Visible = false;
                        picEight.Visible = false;
                        picNine.Visible = false;
                        picTen.Visible = false;
                    }
                    else if (point == 5)
                    {
                        picBlackPuck.Visible = false;
                        picFour.Visible = false;
                        picFive.Visible = true;
                        picSix.Visible = false;
                        picEight.Visible = false;
                        picNine.Visible = false;
                        picTen.Visible = false;
                    }
                    else if (point == 6)
                    {
                        picBlackPuck.Visible = false;
                        picFour.Visible = false;
                        picFive.Visible = false;
                        picSix.Visible = true;
                        picEight.Visible = false;
                        picNine.Visible = false;
                        picTen.Visible = false;
                    }
                    else if (point == 8)
                    {
                        picBlackPuck.Visible = false;
                        picFour.Visible = false;
                        picFive.Visible = false;
                        picSix.Visible = false;
                        picEight.Visible = true;
                        picNine.Visible = false;
                        picTen.Visible = false;
                    }
                    else if (point == 9)
                    {
                        picBlackPuck.Visible = false;
                        picFour.Visible = false;
                        picFive.Visible = false;
                        picSix.Visible = false;
                        picEight.Visible = false;
                        picNine.Visible = true;
                        picTen.Visible = false;
                    }
                    else
                    {
                        picBlackPuck.Visible = false;
                        picFour.Visible = false;
                        picFive.Visible = false;
                        picSix.Visible = false;
                        picEight.Visible = false;
                        picNine.Visible = false;
                        picTen.Visible = true;
                    }
                }
            }

            else //Implies the status is not equal to one
            {
                if (point == RollTotal)
                {
                    lblResults.Visible = true;
                    lblResults.Text = "You Win! Play Again?";
                    picBlackPuck.Visible = true;
                    picFour.Visible = false;
                    picFive.Visible = false;
                    picSix.Visible = false;
                    picEight.Visible = false;
                    picNine.Visible = false;
                    picTen.Visible = false;
                    Score += 1;
                    State = 1;
                    lblGameScore.Text = Score.ToString();
                }
                else if (RollTotal == 7)
                {
                    lblResults.Visible = true;
                    lblResults.Text = "You Lose! Play Again?";
                    picBlackPuck.Visible = true;
                    picFour.Visible = false;
                    picFive.Visible = false;
                    picSix.Visible = false;
                    picEight.Visible = false;
                    picNine.Visible = false;
                    picTen.Visible = false;
                    Score -= 1;
                    State = 1;
                    lblGamePoint.Text = "";
                    lblGameScore.Text = Score.ToString();
                }
                else //implies that the point was not hit
                {
                    lblResults.Visible = true;
                    lblResults.Text = "Roll Again!";
                    Score += 0;
                    State += 1;
                    lblGameScore.Text = Score.ToString();
                }
            }

            //Display the die that corresponds to the roll for Set One
            if (RollOne == 1)
            {
                picDice11.Visible = true;
                picDice12.Visible = false;
                picDice13.Visible = false;
                picDice14.Visible = false;
                picDice15.Visible = false;
                picDice16.Visible = false;
            }
            if (RollOne == 2)
            {
                picDice12.Visible = true;
                picDice11.Visible = false;
                picDice13.Visible = false;
                picDice14.Visible = false;
                picDice15.Visible = false;
                picDice16.Visible = false;
            }
            if (RollOne == 3)
            {
                picDice13.Visible = true;
                picDice11.Visible = false;
                picDice12.Visible = false;
                picDice14.Visible = false;
                picDice15.Visible = false;
                picDice16.Visible = false;
            }
            if (RollOne == 4)
            {
                picDice14.Visible = true;
                picDice11.Visible = false;
                picDice12.Visible = false;
                picDice13.Visible = false;
                picDice15.Visible = false;
                picDice16.Visible = false;
            }
            if (RollOne == 5)
            {
                picDice15.Visible = true;
                picDice11.Visible = false;
                picDice12.Visible = false;
                picDice13.Visible = false;
                picDice14.Visible = false;
                picDice16.Visible = false;

            }
            else if (RollOne == 6)
            {
                picDice16.Visible = true;
                picDice11.Visible = false;
                picDice12.Visible = false;
                picDice13.Visible = false;
                picDice14.Visible = false;
                picDice15.Visible = false;
            }

            //Display the die that corresponds to the roll for Set Two
            if (RollTwo == 1)
            {
                picDice21.Visible = true;
                picDice22.Visible = false;
                picDice23.Visible = false;
                picDice24.Visible = false;
                picDice25.Visible = false;
                picDice26.Visible = false;
            }
            if (RollTwo == 2)
            {
                picDice22.Visible = true;
                picDice21.Visible = false;
                picDice23.Visible = false;
                picDice24.Visible = false;
                picDice25.Visible = false;
                picDice26.Visible = false;
            }
            if (RollTwo == 3)
            {
                picDice23.Visible = true;
                picDice21.Visible = false;
                picDice22.Visible = false;
                picDice24.Visible = false;
                picDice25.Visible = false;
                picDice26.Visible = false;
            }
            if (RollTwo == 4)
            {
                picDice24.Visible = true;
                picDice21.Visible = false;
                picDice22.Visible = false;
                picDice23.Visible = false;
                picDice25.Visible = false;
                picDice26.Visible = false;
            }
            if (RollTwo == 5)
            {
                picDice25.Visible = true;
                picDice21.Visible = false;
                picDice22.Visible = false;
                picDice23.Visible = false;
                picDice24.Visible = false;
                picDice26.Visible = false;

            }
            else if (RollTwo == 6)
            {
                picDice26.Visible = true;
                picDice21.Visible = false;
                picDice22.Visible = false;
                picDice23.Visible = false;
                picDice24.Visible = false;
                picDice25.Visible = false;
            }
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void grpDiceSet1_Enter(object sender, EventArgs e)
        {

        }
    }
}
