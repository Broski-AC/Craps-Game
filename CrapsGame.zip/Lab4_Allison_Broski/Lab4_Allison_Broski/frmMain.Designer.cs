﻿namespace Lab4_Allison_Broski
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRoll = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.picFour = new System.Windows.Forms.PictureBox();
            this.picTen = new System.Windows.Forms.PictureBox();
            this.picNine = new System.Windows.Forms.PictureBox();
            this.picEight = new System.Windows.Forms.PictureBox();
            this.picSix = new System.Windows.Forms.PictureBox();
            this.picFive = new System.Windows.Forms.PictureBox();
            this.picBlackPuck = new System.Windows.Forms.PictureBox();
            this.picDice11 = new System.Windows.Forms.PictureBox();
            this.picDice25 = new System.Windows.Forms.PictureBox();
            this.picDice24 = new System.Windows.Forms.PictureBox();
            this.picDice23 = new System.Windows.Forms.PictureBox();
            this.picDice22 = new System.Windows.Forms.PictureBox();
            this.picDice21 = new System.Windows.Forms.PictureBox();
            this.picDice16 = new System.Windows.Forms.PictureBox();
            this.picDice15 = new System.Windows.Forms.PictureBox();
            this.picDice14 = new System.Windows.Forms.PictureBox();
            this.picDice13 = new System.Windows.Forms.PictureBox();
            this.picDice12 = new System.Windows.Forms.PictureBox();
            this.picDice26 = new System.Windows.Forms.PictureBox();
            this.grpResults = new System.Windows.Forms.GroupBox();
            this.lblGameScore = new System.Windows.Forms.Label();
            this.lblScoreDice2 = new System.Windows.Forms.Label();
            this.lblDiceTotal = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblGamePoint = new System.Windows.Forms.Label();
            this.lblScoreDice1 = new System.Windows.Forms.Label();
            this.lblPoint = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblDie2 = new System.Windows.Forms.Label();
            this.lblDie1 = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlackPuck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice26)).BeginInit();
            this.grpResults.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRoll
            // 
            this.btnRoll.BackColor = System.Drawing.Color.DarkOrange;
            this.btnRoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoll.Location = new System.Drawing.Point(709, 513);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(203, 61);
            this.btnRoll.TabIndex = 0;
            this.btnRoll.Text = "Roll the Dice!";
            this.btnRoll.UseVisualStyleBackColor = false;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Wheat;
            this.btnExit.Location = new System.Drawing.Point(751, 580);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(121, 29);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit the Game";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // picFour
            // 
            this.picFour.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picFour.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck;
            this.picFour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picFour.Location = new System.Drawing.Point(195, 83);
            this.picFour.Name = "picFour";
            this.picFour.Size = new System.Drawing.Size(59, 51);
            this.picFour.TabIndex = 2;
            this.picFour.TabStop = false;
            this.picFour.Visible = false;
            // 
            // picTen
            // 
            this.picTen.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picTen.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck;
            this.picTen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picTen.Location = new System.Drawing.Point(575, 83);
            this.picTen.Name = "picTen";
            this.picTen.Size = new System.Drawing.Size(59, 51);
            this.picTen.TabIndex = 3;
            this.picTen.TabStop = false;
            this.picTen.Visible = false;
            // 
            // picNine
            // 
            this.picNine.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picNine.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck;
            this.picNine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picNine.Location = new System.Drawing.Point(498, 83);
            this.picNine.Name = "picNine";
            this.picNine.Size = new System.Drawing.Size(59, 51);
            this.picNine.TabIndex = 4;
            this.picNine.TabStop = false;
            this.picNine.Visible = false;
            // 
            // picEight
            // 
            this.picEight.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picEight.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck;
            this.picEight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picEight.Location = new System.Drawing.Point(423, 83);
            this.picEight.Name = "picEight";
            this.picEight.Size = new System.Drawing.Size(59, 51);
            this.picEight.TabIndex = 5;
            this.picEight.TabStop = false;
            this.picEight.Visible = false;
            // 
            // picSix
            // 
            this.picSix.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picSix.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck;
            this.picSix.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSix.Location = new System.Drawing.Point(346, 83);
            this.picSix.Name = "picSix";
            this.picSix.Size = new System.Drawing.Size(59, 51);
            this.picSix.TabIndex = 6;
            this.picSix.TabStop = false;
            this.picSix.Visible = false;
            // 
            // picFive
            // 
            this.picFive.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picFive.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck;
            this.picFive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picFive.Location = new System.Drawing.Point(269, 83);
            this.picFive.Name = "picFive";
            this.picFive.Size = new System.Drawing.Size(59, 51);
            this.picFive.TabIndex = 7;
            this.picFive.TabStop = false;
            this.picFive.Visible = false;
            // 
            // picBlackPuck
            // 
            this.picBlackPuck.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.puck2;
            this.picBlackPuck.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBlackPuck.Location = new System.Drawing.Point(677, 45);
            this.picBlackPuck.Name = "picBlackPuck";
            this.picBlackPuck.Size = new System.Drawing.Size(61, 55);
            this.picBlackPuck.TabIndex = 8;
            this.picBlackPuck.TabStop = false;
            // 
            // picDice11
            // 
            this.picDice11.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die1;
            this.picDice11.Location = new System.Drawing.Point(57, 551);
            this.picDice11.Name = "picDice11";
            this.picDice11.Size = new System.Drawing.Size(51, 49);
            this.picDice11.TabIndex = 9;
            this.picDice11.TabStop = false;
            this.picDice11.Visible = false;
            // 
            // picDice25
            // 
            this.picDice25.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die5;
            this.picDice25.Location = new System.Drawing.Point(130, 551);
            this.picDice25.Name = "picDice25";
            this.picDice25.Size = new System.Drawing.Size(51, 49);
            this.picDice25.TabIndex = 10;
            this.picDice25.TabStop = false;
            this.picDice25.Visible = false;
            // 
            // picDice24
            // 
            this.picDice24.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die4;
            this.picDice24.Location = new System.Drawing.Point(130, 551);
            this.picDice24.Name = "picDice24";
            this.picDice24.Size = new System.Drawing.Size(51, 49);
            this.picDice24.TabIndex = 11;
            this.picDice24.TabStop = false;
            this.picDice24.Visible = false;
            // 
            // picDice23
            // 
            this.picDice23.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die3;
            this.picDice23.Location = new System.Drawing.Point(130, 551);
            this.picDice23.Name = "picDice23";
            this.picDice23.Size = new System.Drawing.Size(51, 49);
            this.picDice23.TabIndex = 12;
            this.picDice23.TabStop = false;
            this.picDice23.Visible = false;
            // 
            // picDice22
            // 
            this.picDice22.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die2;
            this.picDice22.Location = new System.Drawing.Point(130, 551);
            this.picDice22.Name = "picDice22";
            this.picDice22.Size = new System.Drawing.Size(51, 49);
            this.picDice22.TabIndex = 13;
            this.picDice22.TabStop = false;
            this.picDice22.Visible = false;
            // 
            // picDice21
            // 
            this.picDice21.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die1;
            this.picDice21.Location = new System.Drawing.Point(130, 551);
            this.picDice21.Name = "picDice21";
            this.picDice21.Size = new System.Drawing.Size(51, 49);
            this.picDice21.TabIndex = 14;
            this.picDice21.TabStop = false;
            this.picDice21.Visible = false;
            // 
            // picDice16
            // 
            this.picDice16.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die6;
            this.picDice16.Location = new System.Drawing.Point(57, 551);
            this.picDice16.Name = "picDice16";
            this.picDice16.Size = new System.Drawing.Size(51, 49);
            this.picDice16.TabIndex = 15;
            this.picDice16.TabStop = false;
            this.picDice16.Visible = false;
            // 
            // picDice15
            // 
            this.picDice15.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die5;
            this.picDice15.Location = new System.Drawing.Point(57, 551);
            this.picDice15.Name = "picDice15";
            this.picDice15.Size = new System.Drawing.Size(51, 49);
            this.picDice15.TabIndex = 16;
            this.picDice15.TabStop = false;
            this.picDice15.Visible = false;
            // 
            // picDice14
            // 
            this.picDice14.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die4;
            this.picDice14.Location = new System.Drawing.Point(57, 551);
            this.picDice14.Name = "picDice14";
            this.picDice14.Size = new System.Drawing.Size(51, 49);
            this.picDice14.TabIndex = 17;
            this.picDice14.TabStop = false;
            this.picDice14.Visible = false;
            // 
            // picDice13
            // 
            this.picDice13.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die3;
            this.picDice13.Location = new System.Drawing.Point(57, 551);
            this.picDice13.Name = "picDice13";
            this.picDice13.Size = new System.Drawing.Size(51, 49);
            this.picDice13.TabIndex = 18;
            this.picDice13.TabStop = false;
            this.picDice13.Visible = false;
            // 
            // picDice12
            // 
            this.picDice12.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die2;
            this.picDice12.Location = new System.Drawing.Point(57, 551);
            this.picDice12.Name = "picDice12";
            this.picDice12.Size = new System.Drawing.Size(51, 49);
            this.picDice12.TabIndex = 19;
            this.picDice12.TabStop = false;
            this.picDice12.Visible = false;
            // 
            // picDice26
            // 
            this.picDice26.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.die6;
            this.picDice26.Location = new System.Drawing.Point(130, 551);
            this.picDice26.Name = "picDice26";
            this.picDice26.Size = new System.Drawing.Size(51, 49);
            this.picDice26.TabIndex = 20;
            this.picDice26.TabStop = false;
            this.picDice26.Visible = false;
            // 
            // grpResults
            // 
            this.grpResults.BackColor = System.Drawing.Color.LightCyan;
            this.grpResults.Controls.Add(this.lblGameScore);
            this.grpResults.Controls.Add(this.lblScoreDice2);
            this.grpResults.Controls.Add(this.lblDiceTotal);
            this.grpResults.Controls.Add(this.label3);
            this.grpResults.Controls.Add(this.lblGamePoint);
            this.grpResults.Controls.Add(this.lblScoreDice1);
            this.grpResults.Controls.Add(this.lblPoint);
            this.grpResults.Controls.Add(this.lblScore);
            this.grpResults.Controls.Add(this.lblTotal);
            this.grpResults.Controls.Add(this.lblDie2);
            this.grpResults.Controls.Add(this.lblDie1);
            this.grpResults.Location = new System.Drawing.Point(677, 118);
            this.grpResults.Name = "grpResults";
            this.grpResults.Size = new System.Drawing.Size(277, 389);
            this.grpResults.TabIndex = 22;
            this.grpResults.TabStop = false;
            this.grpResults.Text = "Results";
            // 
            // lblGameScore
            // 
            this.lblGameScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGameScore.Location = new System.Drawing.Point(112, 291);
            this.lblGameScore.Name = "lblGameScore";
            this.lblGameScore.Size = new System.Drawing.Size(69, 33);
            this.lblGameScore.TabIndex = 7;
            // 
            // lblScoreDice2
            // 
            this.lblScoreDice2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreDice2.Location = new System.Drawing.Point(112, 83);
            this.lblScoreDice2.Name = "lblScoreDice2";
            this.lblScoreDice2.Size = new System.Drawing.Size(69, 33);
            this.lblScoreDice2.TabIndex = 6;
            // 
            // lblDiceTotal
            // 
            this.lblDiceTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiceTotal.Location = new System.Drawing.Point(112, 133);
            this.lblDiceTotal.Name = "lblDiceTotal";
            this.lblDiceTotal.Size = new System.Drawing.Size(69, 33);
            this.lblDiceTotal.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 33);
            this.label3.TabIndex = 5;
            this.label3.Text = "Dice 1";
            // 
            // lblGamePoint
            // 
            this.lblGamePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGamePoint.Location = new System.Drawing.Point(112, 235);
            this.lblGamePoint.Name = "lblGamePoint";
            this.lblGamePoint.Size = new System.Drawing.Size(69, 33);
            this.lblGamePoint.TabIndex = 5;
            // 
            // lblScoreDice1
            // 
            this.lblScoreDice1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreDice1.Location = new System.Drawing.Point(112, 34);
            this.lblScoreDice1.Name = "lblScoreDice1";
            this.lblScoreDice1.Size = new System.Drawing.Size(69, 33);
            this.lblScoreDice1.TabIndex = 4;
            // 
            // lblPoint
            // 
            this.lblPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoint.Location = new System.Drawing.Point(6, 235);
            this.lblPoint.Name = "lblPoint";
            this.lblPoint.Size = new System.Drawing.Size(100, 33);
            this.lblPoint.TabIndex = 3;
            this.lblPoint.Text = "Point";
            // 
            // lblScore
            // 
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(6, 291);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(86, 33);
            this.lblScore.TabIndex = 3;
            this.lblScore.Text = "Score";
            // 
            // lblTotal
            // 
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(6, 136);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(100, 33);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "Total";
            // 
            // lblDie2
            // 
            this.lblDie2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDie2.Location = new System.Drawing.Point(6, 83);
            this.lblDie2.Name = "lblDie2";
            this.lblDie2.Size = new System.Drawing.Size(100, 33);
            this.lblDie2.TabIndex = 1;
            this.lblDie2.Text = "Die 2";
            // 
            // lblDie1
            // 
            this.lblDie1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDie1.Location = new System.Drawing.Point(6, 34);
            this.lblDie1.Name = "lblDie1";
            this.lblDie1.Size = new System.Drawing.Size(100, 33);
            this.lblDie1.TabIndex = 0;
            this.lblDie1.Text = "Die 1";
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.LightCyan;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(200, 551);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(503, 49);
            this.lblResults.TabIndex = 25;
            this.lblResults.Visible = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Lab4_Allison_Broski.Properties.Resources.table;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(991, 632);
            this.Controls.Add(this.picDice24);
            this.Controls.Add(this.picDice25);
            this.Controls.Add(this.picDice23);
            this.Controls.Add(this.picDice26);
            this.Controls.Add(this.picDice22);
            this.Controls.Add(this.picDice21);
            this.Controls.Add(this.picDice14);
            this.Controls.Add(this.picDice15);
            this.Controls.Add(this.picDice16);
            this.Controls.Add(this.picDice13);
            this.Controls.Add(this.picDice11);
            this.Controls.Add(this.picDice12);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.grpResults);
            this.Controls.Add(this.picBlackPuck);
            this.Controls.Add(this.picFive);
            this.Controls.Add(this.picSix);
            this.Controls.Add(this.picEight);
            this.Controls.Add(this.picNine);
            this.Controls.Add(this.picTen);
            this.Controls.Add(this.picFour);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRoll);
            this.Name = "frmMain";
            this.Text = "This is Craps";
            ((System.ComponentModel.ISupportInitialize)(this.picFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBlackPuck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDice26)).EndInit();
            this.grpResults.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox picFour;
        private System.Windows.Forms.PictureBox picTen;
        private System.Windows.Forms.PictureBox picNine;
        private System.Windows.Forms.PictureBox picEight;
        private System.Windows.Forms.PictureBox picSix;
        private System.Windows.Forms.PictureBox picFive;
        private System.Windows.Forms.PictureBox picBlackPuck;
        private System.Windows.Forms.PictureBox picDice11;
        private System.Windows.Forms.PictureBox picDice25;
        private System.Windows.Forms.PictureBox picDice24;
        private System.Windows.Forms.PictureBox picDice23;
        private System.Windows.Forms.PictureBox picDice22;
        private System.Windows.Forms.PictureBox picDice21;
        private System.Windows.Forms.PictureBox picDice16;
        private System.Windows.Forms.PictureBox picDice15;
        private System.Windows.Forms.PictureBox picDice14;
        private System.Windows.Forms.PictureBox picDice13;
        private System.Windows.Forms.PictureBox picDice12;
        private System.Windows.Forms.PictureBox picDice26;
        private System.Windows.Forms.GroupBox grpResults;
        private System.Windows.Forms.Label lblGameScore;
        private System.Windows.Forms.Label lblScoreDice2;
        private System.Windows.Forms.Label lblDiceTotal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblGamePoint;
        private System.Windows.Forms.Label lblScoreDice1;
        private System.Windows.Forms.Label lblPoint;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblDie2;
        private System.Windows.Forms.Label lblDie1;
        private System.Windows.Forms.Label lblResults;
    }
}

